# Portfolio — Vanilla HTML/CSS/JS

Portfolio sederhana, responsive, tanpa framework. Siap di-push ke GitHub dan dipublish menggunakan GitHub Pages.

## Struktur

```text
portfolio/
├── index.html
├── style.css
├── script.js
├── assets/
└── README.md
```

## Cara menjalankan

Buka `index.html` langsung di browser. Tidak membutuhkan Node.js atau build tool.

## Sebelum dipublish

Edit bagian berikut di `index.html`:

- Nama dan deskripsi profil.
- Email pada tombol `mailto:`.
- Link GitHub.
- Link LinkedIn.
- Judul, deskripsi, dan link project.
- Tambahkan foto profil/project ke folder `assets/` jika diperlukan.

## GitHub Pages

1. Buat repository baru di GitHub.
2. Upload semua isi folder ini.
3. Masuk ke **Settings → Pages**.
4. Pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`.
6. Save.

Website akan tersedia melalui URL GitHub Pages repository tersebut.

## Catatan

Google Fonts digunakan melalui CDN. Jika ingin benar-benar tanpa dependensi eksternal, hapus link Google Fonts dari `index.html` dan gunakan font system bawaan.
